public class Main {
    public static void main(String[] args) {
        new StartFrame().setVisible(true);
    }
}
